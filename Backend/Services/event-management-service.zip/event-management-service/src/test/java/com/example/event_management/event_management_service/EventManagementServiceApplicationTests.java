package com.example.event_management.event_management_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventManagementServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
